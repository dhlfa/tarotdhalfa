'use client'

import { motion } from 'framer-motion'

export function Header() {
  return (
    <header className="relative z-10 py-8 sm:py-12 px-4 text-center">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="space-y-4"
      >
        {/* Decorative element */}
        <div className="flex items-center justify-center gap-3 text-gold/40">
          <span className="text-lg">✧</span>
          <div className="w-16 h-px bg-gradient-to-r from-transparent via-gold/40 to-transparent" />
          <span className="text-2xl">☽</span>
          <div className="w-16 h-px bg-gradient-to-r from-transparent via-gold/40 to-transparent" />
          <span className="text-lg">✧</span>
        </div>

        {/* Title */}
        <h1 className="text-3xl sm:text-4xl md:text-5xl font-serif font-semibold text-foreground tracking-wide">
          <span className="text-gold">The Tarot Club</span>
        </h1>

        {/* Subtitle */}
        <p className="text-base sm:text-lg text-muted-foreground/80 font-serif italic tracking-wide">
          Di Atas Kabut Abu-Abu
        </p>

        {/* Description */}
        <p className="max-w-lg mx-auto text-sm text-muted-foreground/60 leading-relaxed">
          Selamat datang, pencari kebenaran. Duduklah di meja bundar ini 
          dan biarkan kartu-kartu mengungkapkan rahasia takdirmu.
        </p>

        {/* Decorative line */}
        <div className="flex items-center justify-center pt-4">
          <div className="w-32 sm:w-48 h-px bg-gradient-to-r from-transparent via-gold/30 to-transparent" />
        </div>
      </motion.div>
    </header>
  )
}
