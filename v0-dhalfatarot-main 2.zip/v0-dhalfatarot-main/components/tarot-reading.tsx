'use client'

import { useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { TarotCard } from './tarot-card'
import { CardSelector } from './card-selector'
import { ShuffleAnimation } from './shuffle-animation'
import { ReadingDisplay } from './reading-display'
import { shuffleAndDraw, type DrawnCard } from '@/lib/tarot-data'

type Phase = 'input' | 'shuffling' | 'reveal' | 'reading'

export function TarotReading() {
  const [phase, setPhase] = useState<Phase>('input')
  const [userName, setUserName] = useState('')
  const [question, setQuestion] = useState('')
  const [cardCount, setCardCount] = useState(3)
  const [drawnCards, setDrawnCards] = useState<DrawnCard[]>([])
  const [reading, setReading] = useState('')
  const [isLoadingReading, setIsLoadingReading] = useState(false)

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault()
    if (!userName.trim() || !question.trim()) return

    // Start shuffling phase
    setPhase('shuffling')
    
    // Simulate shuffle time
    await new Promise(resolve => setTimeout(resolve, 2500))
    
    // Draw cards
    const cards = shuffleAndDraw(cardCount)
    setDrawnCards(cards)
    setPhase('reveal')
  }, [userName, question, cardCount])

  const handleRevealCard = useCallback((index: number) => {
    setDrawnCards(prev => prev.map((card, i) => 
      i === index ? { ...card, isRevealed: true } : card
    ))
  }, [])

  const allCardsRevealed = drawnCards.length > 0 && drawnCards.every(c => c.isRevealed)

  const handleGetReading = useCallback(async () => {
    setPhase('reading')
    setIsLoadingReading(true)
    
    try {
      console.log('[TarotReading] Calling /api/tarot with:', {
        userName,
        question,
        cardCount: drawnCards.length
      })

      const response = await fetch('/api/tarot', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userName,
          question,
          drawnCards
        })
      })

      console.log('[TarotReading] API Response status:', response.status)

      if (!response.ok) {
        const errorData = await response.json()
        console.error('[TarotReading] API Error:', errorData)
        setReading(errorData.error || 'Terjadi kesalahan dalam membaca kartu.')
        return
      }

      const data = await response.json()
      console.log('[TarotReading] API Success, setting reading')
      setReading(data.reading)
    } catch (error) {
      console.error('[TarotReading] Fetch error:', error)
      setReading('Terjadi kesalahan dalam menghubungi Sefirah Castle. Periksa koneksi internet.')
    } finally {
      setIsLoadingReading(false)
    }
  }, [userName, question, drawnCards])

  const handleReset = useCallback(() => {
    setPhase('input')
    setUserName('')
    setQuestion('')
    setCardCount(3)
    setDrawnCards([])
    setReading('')
  }, [])

  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-8 sm:py-12">
      <AnimatePresence mode="wait">
        {/* Shuffle Animation Overlay */}
        <ShuffleAnimation isShuffling={phase === 'shuffling'} />

        {/* Input Phase */}
        {phase === 'input' && (
          <motion.div
            key="input"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.5 }}
          >
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Name Input */}
              <div className="space-y-2">
                <label htmlFor="name" className="block text-sm font-serif text-foreground/90 tracking-wide">
                  Namamu, Pencari Kebenaran
                </label>
                <input
                  type="text"
                  id="name"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="Masukkan namamu..."
                  required
                  className="w-full px-4 py-3 bg-card/50 border border-border/50 rounded-lg 
                    text-foreground placeholder:text-muted-foreground/50 
                    focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/30
                    font-sans text-base transition-all duration-300"
                />
              </div>

              {/* Question Input */}
              <div className="space-y-2">
                <label htmlFor="question" className="block text-sm font-serif text-foreground/90 tracking-wide">
                  Pertanyaanmu untuk Kabut Abu-Abu
                </label>
                <textarea
                  id="question"
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  placeholder="Apa yang ingin kau ketahui dari takdir?"
                  required
                  rows={4}
                  className="w-full px-4 py-3 bg-card/50 border border-border/50 rounded-lg 
                    text-foreground placeholder:text-muted-foreground/50 
                    focus:outline-none focus:border-gold/50 focus:ring-1 focus:ring-gold/30
                    font-sans text-base resize-none transition-all duration-300"
                />
              </div>

              {/* Card Count Selector */}
              <CardSelector value={cardCount} onChange={setCardCount} />

              {/* Submit Button */}
              <motion.button
                type="submit"
                disabled={!userName.trim() || !question.trim()}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full py-4 px-6 bg-gradient-to-r from-gold/20 via-gold/30 to-gold/20 
                  border-2 border-gold/50 rounded-lg text-gold font-serif text-lg tracking-wider
                  hover:from-gold/30 hover:via-gold/40 hover:to-gold/30 hover:border-gold/70
                  hover:shadow-lg hover:shadow-gold/20
                  disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100
                  transition-all duration-300 mystical-glow"
              >
                <span className="flex items-center justify-center gap-3">
                  <span className="text-xl">✧</span>
                  <span>Panggil Tarot Club</span>
                  <span className="text-xl">✧</span>
                </span>
              </motion.button>
            </form>
          </motion.div>
        )}

        {/* Reveal Phase */}
        {phase === 'reveal' && (
          <motion.div
            key="reveal"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-8"
          >
            {/* Instructions */}
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center space-y-2"
            >
              <h2 className="text-xl sm:text-2xl font-serif text-gold tracking-wide">
                Kartu Telah Terpilih
              </h2>
              <p className="text-sm text-muted-foreground/70">
                {allCardsRevealed 
                  ? 'Semua kartu telah terungkap. Klik tombol di bawah untuk melihat pembacaan.'
                  : 'Klik setiap kartu untuk mengungkapkan rahasianya'
                }
              </p>
            </motion.div>

            {/* Cards Display */}
            <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6">
              {drawnCards.map((drawnCard, index) => (
                <TarotCard
                  key={`${drawnCard.card.id}-${index}`}
                  drawnCard={drawnCard}
                  index={index}
                  onReveal={() => handleRevealCard(index)}
                />
              ))}
            </div>

            {/* Get Reading Button */}
            <AnimatePresence>
              {allCardsRevealed && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 20 }}
                  className="flex justify-center pt-4"
                >
                  <motion.button
                    onClick={handleGetReading}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-8 py-3 bg-gradient-to-r from-crimson/20 via-crimson/30 to-crimson/20 
                      border-2 border-crimson/50 rounded-lg text-crimson font-serif tracking-wider
                      hover:from-crimson/30 hover:via-crimson/40 hover:to-crimson/30 hover:border-crimson/70
                      hover:shadow-lg hover:shadow-crimson/20
                      transition-all duration-300"
                  >
                    <span className="flex items-center gap-2">
                      <span>✧</span>
                      <span>Terima Wahyu Ilahi</span>
                      <span>✧</span>
                    </span>
                  </motion.button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        )}

        {/* Reading Phase */}
        {phase === 'reading' && (
          <motion.div
            key="reading"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-8"
          >
            {/* Cards Summary */}
            <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-4">
              {drawnCards.map((drawnCard, index) => (
                <motion.div
                  key={`summary-${drawnCard.card.id}-${index}`}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className={`w-12 h-18 sm:w-14 sm:h-20 bg-card/50 border border-gold/30 rounded-lg flex items-center justify-center
                    ${drawnCard.isReversed ? 'rotate-180' : ''}`}
                  >
                    <span className="text-lg sm:text-xl text-gold">
                      {drawnCard.card.id}
                    </span>
                  </div>
                  <p className="mt-1 text-[10px] sm:text-xs text-muted-foreground/60 max-w-16 sm:max-w-20 truncate">
                    {drawnCard.card.name}
                  </p>
                </motion.div>
              ))}
            </div>

            {/* Reading Display */}
            <ReadingDisplay reading={reading} isLoading={isLoadingReading} />

            {/* Reset Button */}
            {!isLoadingReading && reading && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
                className="flex justify-center pt-4"
              >
                <motion.button
                  onClick={handleReset}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-6 py-2.5 bg-secondary/50 border border-border/50 rounded-lg 
                    text-foreground/70 font-serif text-sm tracking-wide
                    hover:bg-secondary hover:text-foreground hover:border-gold/30
                    transition-all duration-300"
                >
                  Mulai Pembacaan Baru
                </motion.button>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
