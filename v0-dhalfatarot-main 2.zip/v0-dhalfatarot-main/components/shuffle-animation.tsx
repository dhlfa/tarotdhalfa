'use client'

import { motion } from 'framer-motion'

interface ShuffleAnimationProps {
  isShuffling: boolean
}

export function ShuffleAnimation({ isShuffling }: ShuffleAnimationProps) {
  if (!isShuffling) return null

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-background/90 backdrop-blur-sm"
    >
      <div className="relative flex flex-col items-center gap-8">
        {/* Shuffling cards */}
        <div className="relative w-40 h-56">
          {[...Array(5)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute inset-0"
              animate={{
                x: [0, (i - 2) * 20, 0, (2 - i) * 20, 0],
                y: [0, -30, 0, -30, 0],
                rotateZ: [0, (i - 2) * 10, 0, (2 - i) * 10, 0],
                rotateY: [0, 180, 360, 540, 720],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: i * 0.1,
                ease: 'easeInOut',
              }}
            >
              <div className="w-full h-full bg-gradient-to-br from-[#1a1a2e] via-[#16162a] to-[#0f0f1a] rounded-lg border border-gold/30 shadow-xl">
                <div className="absolute inset-2 border border-gold/20 rounded-md flex items-center justify-center">
                  <div className="w-12 h-12 border border-gold/30 rounded-full flex items-center justify-center">
                    <span className="text-gold/50 text-xl">✧</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Text */}
        <motion.div
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="text-center space-y-2"
        >
          <h3 className="text-xl sm:text-2xl font-serif text-gold tracking-wider">
            Mengacak Kartu...
          </h3>
          <p className="text-sm text-muted-foreground/70 font-sans">
            Kabut abu-abu bergerak, takdir sedang ditenun
          </p>
        </motion.div>

        {/* Mystical particles */}
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={`particle-${i}`}
            className="absolute w-1 h-1 bg-gold/60 rounded-full"
            animate={{
              x: [0, Math.cos(i * 30 * Math.PI / 180) * 150],
              y: [0, Math.sin(i * 30 * Math.PI / 180) * 150],
              opacity: [0, 1, 0],
              scale: [0, 1, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: i * 0.15,
              ease: 'easeOut',
            }}
            style={{
              left: '50%',
              top: '40%',
            }}
          />
        ))}
      </div>
    </motion.div>
  )
}
