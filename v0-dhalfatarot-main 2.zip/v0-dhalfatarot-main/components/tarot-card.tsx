'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import Image from 'next/image'
import type { DrawnCard } from '@/lib/tarot-data'

interface TarotCardProps {
  drawnCard: DrawnCard
  index: number
  onReveal: () => void
}

// Card back design - mystical dark pattern
function CardBack() {
  return (
    <div className="absolute inset-0 bg-gradient-to-br from-[#0a0a15] via-[#12121f] to-[#0a0a15] rounded-xl overflow-hidden border-2 border-gold/30">
      {/* Outer ornate border */}
      <div className="absolute inset-1 border border-gold/20 rounded-lg" />
      <div className="absolute inset-2 border border-gold/10 rounded-md" />
      
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-20">
        <svg viewBox="0 0 100 150" className="w-full h-full" preserveAspectRatio="none">
          <defs>
            <pattern id="card-pattern" x="0" y="0" width="10" height="10" patternUnits="userSpaceOnUse">
              <circle cx="5" cy="5" r="0.5" fill="#b4965a" />
            </pattern>
            <radialGradient id="center-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#b4965a" stopOpacity="0.3" />
              <stop offset="100%" stopColor="#b4965a" stopOpacity="0" />
            </radialGradient>
          </defs>
          <rect width="100" height="150" fill="url(#card-pattern)" />
          <ellipse cx="50" cy="75" rx="35" ry="45" fill="url(#center-glow)" />
        </svg>
      </div>
      
      {/* Center mystical emblem */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="relative">
          {/* Rotating outer ring */}
          <motion.div 
            className="w-20 h-20 sm:w-24 sm:h-24 border-2 border-gold/40 rounded-full flex items-center justify-center"
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            {/* Decorative dots */}
            {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => (
              <div
                key={deg}
                className="absolute w-1.5 h-1.5 bg-gold/50 rounded-full"
                style={{
                  transform: `rotate(${deg}deg) translateY(-40px)`,
                  transformOrigin: 'center center',
                }}
              />
            ))}
          </motion.div>
          
          {/* Inner static ring */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-14 h-14 sm:w-16 sm:h-16 border border-gold/30 rounded-full flex items-center justify-center">
              {/* All-seeing eye */}
              <motion.div
                animate={{ 
                  opacity: [0.5, 1, 0.5],
                  scale: [0.95, 1.05, 0.95]
                }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              >
                <svg viewBox="0 0 24 24" className="w-8 h-8 sm:w-10 sm:h-10 text-gold/70">
                  <path
                    fill="currentColor"
                    d="M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zM12 17c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5zm0-8c-1.66 0-3 1.34-3 3s1.34 3 3 3 3-1.34 3-3-1.34-3-3-3z"
                  />
                </svg>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Corner decorations */}
      <div className="absolute top-4 left-4 text-gold/40 text-sm font-serif">✧</div>
      <div className="absolute top-4 right-4 text-gold/40 text-sm font-serif">✧</div>
      <div className="absolute bottom-4 left-4 text-gold/40 text-sm font-serif">✧</div>
      <div className="absolute bottom-4 right-4 text-gold/40 text-sm font-serif">✧</div>
      
      {/* Shimmer effect */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-transparent via-gold/10 to-transparent"
        animate={{ x: ['-100%', '200%'] }}
        transition={{ duration: 3, repeat: Infinity, ease: "easeInOut", repeatDelay: 2 }}
      />
    </div>
  )
}

// Card front with actual tarot image
function CardFront({ drawnCard }: { drawnCard: DrawnCard }) {
  const { card, isReversed } = drawnCard
  const [imageLoaded, setImageLoaded] = useState(false)
  
  return (
    <div className={`absolute inset-0 bg-gradient-to-br from-[#1a1a2e] via-[#16162a] to-[#0f0f1a] rounded-xl overflow-hidden border-2 border-gold/40 ${isReversed ? 'rotate-180' : ''}`}>
      {/* Card frame */}
      <div className="absolute inset-1 border border-gold/30 rounded-lg" />
      
      {/* Image container */}
      <div className="absolute inset-3 rounded-md overflow-hidden">
        {/* Background placeholder with mystical pattern while loading */}
        <div className={`absolute inset-0 bg-gradient-to-br from-crimson/20 via-gold/10 to-crimson/20 flex items-center justify-center transition-opacity duration-500 ${imageLoaded ? 'opacity-0' : 'opacity-100'}`}>
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
            className="w-12 h-12 border-2 border-gold/30 border-t-gold rounded-full"
          />
        </div>
        
        {/* Actual card image */}
        <Image
          src={card.imageUrl}
          alt={card.name}
          fill
          className={`object-cover transition-opacity duration-500 ${imageLoaded ? 'opacity-100' : 'opacity-0'}`}
          onLoad={() => setImageLoaded(true)}
          sizes="(max-width: 640px) 96px, (max-width: 768px) 112px, 128px"
        />
        
        {/* Overlay gradient for better text readability */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
      </div>
      
      {/* Card number at top */}
      <div className={`absolute top-5 left-0 right-0 flex justify-center ${isReversed ? 'rotate-180' : ''}`}>
        <span className="text-gold/70 text-xs font-serif tracking-widest">
          {card.id === 0 ? 'O' : card.id.toString().padStart(2, '0')}
        </span>
      </div>
      
      {/* Card name at bottom */}
      <div className={`absolute bottom-4 left-0 right-0 text-center px-2 ${isReversed ? 'rotate-180' : ''}`}>
        <div className="text-gold text-xs sm:text-sm font-serif font-semibold tracking-wide leading-tight drop-shadow-lg">
          {card.name}
        </div>
        <div className="text-gold/60 text-[9px] sm:text-[10px] italic mt-0.5">
          {card.nameLatin}
        </div>
        <div className={`text-[8px] sm:text-[9px] font-medium tracking-wider uppercase mt-1 ${isReversed ? 'text-crimson' : 'text-gold/60'}`}>
          {isReversed ? 'Terbalik' : 'Tegak'}
        </div>
      </div>
      
      {/* Mystical glow effect on reveal */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ opacity: [0, 0.3, 0] }}
        transition={{ duration: 1.5, delay: 0.3 }}
        style={{
          background: 'radial-gradient(circle at center, rgba(180, 150, 90, 0.4) 0%, transparent 70%)'
        }}
      />
    </div>
  )
}

export function TarotCard({ drawnCard, index, onReveal }: TarotCardProps) {
  const { isRevealed } = drawnCard
  const [isFlipping, setIsFlipping] = useState(false)

  const handleClick = () => {
    if (isRevealed || isFlipping) return
    setIsFlipping(true)
    
    // Trigger the flip animation
    setTimeout(() => {
      onReveal()
      setIsFlipping(false)
    }, 400) // Halfway through the flip
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 50, rotateY: -30 }}
      animate={{ opacity: 1, y: 0, rotateY: 0 }}
      transition={{ 
        duration: 0.6, 
        delay: index * 0.15,
        type: 'spring',
        stiffness: 100
      }}
      className="perspective-1000"
    >
      <motion.button
        onClick={handleClick}
        disabled={isRevealed}
        whileHover={!isRevealed ? { scale: 1.05, y: -8, rotateY: 5 } : {}}
        whileTap={!isRevealed ? { scale: 0.98 } : {}}
        className={`relative w-24 h-40 sm:w-28 sm:h-44 md:w-32 md:h-52 preserve-3d cursor-pointer
          ${!isRevealed ? 'hover:shadow-2xl hover:shadow-gold/30' : 'cursor-default'}`}
        style={{
          transformStyle: 'preserve-3d',
        }}
        aria-label={isRevealed ? `${drawnCard.card.name} revealed` : 'Click to reveal card'}
      >
        {/* Card container with 3D flip */}
        <motion.div
          className="absolute inset-0 preserve-3d"
          animate={{ 
            rotateY: isRevealed || isFlipping ? 180 : 0 
          }}
          transition={{ 
            duration: 0.8,
            ease: [0.4, 0, 0.2, 1]
          }}
          style={{
            transformStyle: 'preserve-3d',
          }}
        >
          {/* Back of card (visible first) */}
          <div 
            className="absolute inset-0 backface-hidden rounded-xl shadow-xl"
            style={{ 
              backfaceVisibility: 'hidden',
            }}
          >
            <CardBack />
          </div>
          
          {/* Front of card (hidden initially) */}
          <div 
            className="absolute inset-0 backface-hidden rounded-xl shadow-xl"
            style={{ 
              backfaceVisibility: 'hidden',
              transform: 'rotateY(180deg)',
            }}
          >
            <CardFront drawnCard={drawnCard} />
          </div>
        </motion.div>
      </motion.button>
      
      {/* Label below card */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: index * 0.15 + 0.3 }}
        className="mt-3 text-center"
      >
        <span className={`text-xs font-serif transition-colors duration-500 ${isRevealed ? 'text-gold' : 'text-muted-foreground/60'}`}>
          {isRevealed ? drawnCard.card.name : `Kartu ${index + 1}`}
        </span>
      </motion.div>
    </motion.div>
  )
}
