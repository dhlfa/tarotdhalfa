'use client'

import { motion } from 'framer-motion'

interface CardSelectorProps {
  value: number
  onChange: (value: number) => void
}

export function CardSelector({ value, onChange }: CardSelectorProps) {
  const options = [1, 2, 3, 4, 5]

  return (
    <div className="space-y-3">
      <label className="block text-sm font-serif text-foreground/90 tracking-wide">
        Jumlah Kartu yang Ditarik
      </label>
      
      <div className="flex items-center justify-center gap-2 sm:gap-3">
        {options.map((num) => (
          <motion.button
            key={num}
            type="button"
            onClick={() => onChange(num)}
            whileHover={{ scale: 1.1, y: -2 }}
            whileTap={{ scale: 0.95 }}
            className={`relative w-10 h-10 sm:w-12 sm:h-12 rounded-lg border-2 transition-all duration-300 font-serif text-lg sm:text-xl
              ${value === num 
                ? 'border-gold bg-gold/10 text-gold shadow-lg shadow-gold/20' 
                : 'border-border/50 bg-card/50 text-muted-foreground hover:border-gold/50 hover:text-foreground'
              }`}
            aria-label={`Select ${num} card${num > 1 ? 's' : ''}`}
            aria-pressed={value === num}
          >
            {num}
            {value === num && (
              <motion.div
                layoutId="card-selector-highlight"
                className="absolute inset-0 border-2 border-gold rounded-lg"
                transition={{ type: 'spring', bounce: 0.3, duration: 0.5 }}
              />
            )}
          </motion.button>
        ))}
      </div>
      
      <p className="text-center text-xs text-muted-foreground/70 font-sans">
        {getSpreadDescription(value)}
      </p>
    </div>
  )
}

function getSpreadDescription(count: number): string {
  switch (count) {
    case 1:
      return 'Jawaban langsung dan murni'
    case 2:
      return 'Tantangan & Solusi'
    case 3:
      return 'Masa Lalu • Kini • Masa Depan'
    case 4:
      return 'Situasi • Tantangan • Nasihat • Hasil'
    case 5:
      return 'Formasi Salib Penuh'
    default:
      return ''
  }
}
