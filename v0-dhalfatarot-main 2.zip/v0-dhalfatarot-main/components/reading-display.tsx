'use client'

import { motion } from 'framer-motion'
import ReactMarkdown from 'react-markdown'

interface ReadingDisplayProps {
  reading: string
  isLoading: boolean
}

export function ReadingDisplay({ reading, isLoading }: ReadingDisplayProps) {
  if (isLoading) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="w-full max-w-3xl mx-auto"
      >
        <div className="bg-card/50 backdrop-blur-sm border border-border/50 rounded-xl p-6 sm:p-8">
          <div className="flex flex-col items-center gap-4">
            {/* Loading animation */}
            <div className="relative w-16 h-16">
              <motion.div
                className="absolute inset-0 border-2 border-gold/30 rounded-full"
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
              />
              <motion.div
                className="absolute inset-2 border-2 border-t-gold border-r-transparent border-b-transparent border-l-transparent rounded-full"
                animate={{ rotate: -360 }}
                transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-gold text-xl">✧</span>
              </div>
            </div>
            
            <div className="text-center space-y-2">
              <motion.p
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="text-lg font-serif text-gold"
              >
                Membaca Takdir...
              </motion.p>
              <p className="text-sm text-muted-foreground/70">
                The Fool sedang menafsirkan kartu-kartu yang terpilih
              </p>
            </div>
          </div>
        </div>
      </motion.div>
    )
  }

  if (!reading) return null

  // Check if this is an API error message
  const isError = reading.includes('Koneksi ke Sefirah Castle Terputus') || reading.includes('API Key Belum Valid')

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="w-full max-w-3xl mx-auto"
    >
      <div className={`backdrop-blur-sm rounded-xl overflow-hidden shadow-2xl ${
        isError 
          ? 'bg-red-950/60 border-2 border-red-500/50 shadow-red-500/10' 
          : 'bg-card/60 border border-gold/20 shadow-gold/5'
      }`}>
        {/* Header decoration */}
        <div className={`h-1 bg-gradient-to-r from-transparent ${isError ? 'via-red-500/70' : 'via-gold/50'} to-transparent`} />
        
        {/* Content */}
        <div className="p-6 sm:p-8 md:p-10">
          {isError ? (
            <div className="text-center space-y-4">
              <div className="text-red-400 text-4xl">⚠</div>
              <article className="prose prose-invert max-w-none
                prose-headings:font-serif prose-headings:text-red-400 prose-headings:tracking-wide
                prose-h2:text-xl prose-h2:sm:text-2xl prose-h2:border-b prose-h2:border-red-500/20 prose-h2:pb-3 prose-h2:mb-6
                prose-p:text-red-200/90 prose-p:leading-relaxed prose-p:font-sans
                prose-strong:text-red-300 prose-strong:font-semibold
                prose-code:text-red-300 prose-code:bg-red-950/50 prose-code:px-1.5 prose-code:py-0.5 prose-code:rounded
              ">
                <ReactMarkdown>{reading}</ReactMarkdown>
              </article>
            </div>
          ) : (
            <article className="prose prose-invert prose-gold max-w-none
              prose-headings:font-serif prose-headings:text-gold prose-headings:tracking-wide
              prose-h2:text-xl prose-h2:sm:text-2xl prose-h2:border-b prose-h2:border-gold/20 prose-h2:pb-3 prose-h2:mb-6
              prose-p:text-foreground/90 prose-p:leading-relaxed prose-p:font-sans
              prose-strong:text-gold prose-strong:font-semibold
              prose-em:text-foreground/70 prose-em:font-sans
              prose-ul:text-foreground/80
              prose-li:marker:text-gold/50
            ">
              <ReactMarkdown>{reading}</ReactMarkdown>
            </article>
          )}
        </div>
        
        {/* Footer decoration */}
        {!isError && (
          <div className="px-6 sm:px-8 md:px-10 pb-6 sm:pb-8">
            <div className="flex items-center justify-center gap-4 pt-6 border-t border-gold/10">
              <span className="text-gold/30">✧</span>
              <span className="text-xs text-muted-foreground/50 font-serif tracking-widest uppercase">
                Tarot Club
              </span>
              <span className="text-gold/30">✧</span>
            </div>
          </div>
        )}
      </div>
    </motion.div>
  )
}
