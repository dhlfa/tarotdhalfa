'use client'

import { motion } from 'framer-motion'

export function Footer() {
  return (
    <footer className="relative z-10 py-8 sm:py-12 px-4 mt-auto">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.5 }}
        className="max-w-4xl mx-auto"
      >
        {/* Decorative line */}
        <div className="flex items-center justify-center pb-6">
          <div className="w-48 h-px bg-gradient-to-r from-transparent via-gold/20 to-transparent" />
        </div>

        {/* Credit section */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-2 text-gold/30">
            <span>✧</span>
            <span className="text-xs tracking-widest uppercase">Sefirah Castle</span>
            <span>✧</span>
          </div>

          {/* Creator credit */}
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground/50 tracking-wide">
              Created by
            </p>
            <p className="text-sm font-serif text-gold/80 tracking-wider">
              Dhalfa Airus (The Fool)
            </p>
          </div>

          {/* Theme credit */}
          <p className="text-[10px] text-muted-foreground/40 max-w-sm mx-auto leading-relaxed">
            Terinspirasi dari donghua/novel &ldquo;Lord of the Mysteries&rdquo; 
            — The Tarot Club Above the Grey Fog
          </p>

          {/* Copyright */}
          <p className="text-[10px] text-muted-foreground/30 pt-2">
            &copy; {new Date().getFullYear()} &mdash; All mysteries preserved in the grey fog
          </p>
        </div>

        {/* Bottom decoration */}
        <div className="flex items-center justify-center gap-3 pt-6 text-gold/20">
          <div className="w-8 h-px bg-gold/20" />
          <span className="text-xs">☽</span>
          <div className="w-8 h-px bg-gold/20" />
        </div>
      </motion.div>
    </footer>
  )
}
