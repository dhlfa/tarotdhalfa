export interface TarotCard {
  id: number
  name: string
  nameLatin: string
  meaning: {
    upright: string
    reversed: string
  }
  description: string
  imageUrl: string
}

export const majorArcana: TarotCard[] = [
  {
    id: 0,
    name: "The Fool",
    nameLatin: "Le Mat",
    meaning: {
      upright: "Awal baru, kepolosan, petualangan, spontanitas",
      reversed: "Kecerobohan, pengambilan risiko, ketidakpastian"
    },
    description: "Sang Pelancong yang berjalan di tepi jurang, membawa hanya kepercayaan dan harapan.",
    imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&h=600&fit=crop"
  },
  {
    id: 1,
    name: "The Magician",
    nameLatin: "Le Bateleur",
    meaning: {
      upright: "Manifestasi, kekuatan, inspirasi, kelicikan",
      reversed: "Manipulasi, kekuatan terpendam, penipuan"
    },
    description: "Penyihir yang menguasai empat elemen, penghubung antara langit dan bumi.",
    imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=600&fit=crop"
  },
  {
    id: 2,
    name: "The High Priestess",
    nameLatin: "La Papesse",
    meaning: {
      upright: "Intuisi, misteri, kebijaksanaan tersembunyi",
      reversed: "Rahasia, penarikan diri, keheningan"
    },
    description: "Penjaga pengetahuan kuno, duduk di antara dua pilar kegelapan dan cahaya.",
    imageUrl: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=600&fit=crop"
  },
  {
    id: 3,
    name: "The Empress",
    nameLatin: "L'Impératrice",
    meaning: {
      upright: "Kesuburan, kelimpahan, alam, kreativitas",
      reversed: "Ketergantungan, blokir kreatif, kekosongan"
    },
    description: "Ibu dari segala kehidupan, dikelilingi oleh kemakmuran alam.",
    imageUrl: "https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=400&h=600&fit=crop"
  },
  {
    id: 4,
    name: "The Emperor",
    nameLatin: "L'Empereur",
    meaning: {
      upright: "Otoritas, struktur, kepemimpinan, stabilitas",
      reversed: "Tirani, kekakuan, dominasi"
    },
    description: "Penguasa yang duduk di singgasana batu, simbol kekuatan dan hukum.",
    imageUrl: "https://images.unsplash.com/photo-1566753323558-f4e0952af115?w=400&h=600&fit=crop"
  },
  {
    id: 5,
    name: "The Hierophant",
    nameLatin: "Le Pape",
    meaning: {
      upright: "Tradisi, konformitas, moralitas, keyakinan",
      reversed: "Pemberontakan, subversi, kebebasan"
    },
    description: "Guru spiritual yang memegang kunci pengetahuan suci.",
    imageUrl: "https://images.unsplash.com/photo-1548625149-fc4a29cf7092?w=400&h=600&fit=crop"
  },
  {
    id: 6,
    name: "The Lovers",
    nameLatin: "L'Amoureux",
    meaning: {
      upright: "Cinta, harmoni, pilihan, keselarasan nilai",
      reversed: "Disharmoni, ketidakseimbangan, salah pilih"
    },
    description: "Dua jiwa yang bersatu di bawah berkat malaikat.",
    imageUrl: "https://images.unsplash.com/photo-1516589178581-6cd7833ae3b2?w=400&h=600&fit=crop"
  },
  {
    id: 7,
    name: "The Chariot",
    nameLatin: "Le Chariot",
    meaning: {
      upright: "Kemenangan, tekad, kendali, ambisi",
      reversed: "Agresi, kurang arah, hambatan"
    },
    description: "Prajurit yang mengendalikan kereta perang dengan dua sphinx.",
    imageUrl: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=600&fit=crop"
  },
  {
    id: 8,
    name: "Strength",
    nameLatin: "La Force",
    meaning: {
      upright: "Keberanian, persuasi, pengaruh, kasih sayang",
      reversed: "Keraguan diri, kelemahan, ketidakamanan"
    },
    description: "Wanita yang menjinakkan singa dengan kelembutan, bukan kekerasan.",
    imageUrl: "https://images.unsplash.com/photo-1517849845537-4d257902454a?w=400&h=600&fit=crop"
  },
  {
    id: 9,
    name: "The Hermit",
    nameLatin: "L'Ermite",
    meaning: {
      upright: "Introspeksi, pencarian, bimbingan dari dalam",
      reversed: "Isolasi, kesepian, penarikan diri"
    },
    description: "Pencari kebenaran yang menerangi jalan dengan lentera kebijaksanaan.",
    imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=600&fit=crop"
  },
  {
    id: 10,
    name: "Wheel of Fortune",
    nameLatin: "La Roue de Fortune",
    meaning: {
      upright: "Perubahan, siklus, takdir, keberuntungan",
      reversed: "Nasib buruk, penolakan perubahan, chaos"
    },
    description: "Roda takdir yang terus berputar, mengangkat dan menjatuhkan.",
    imageUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=400&h=600&fit=crop"
  },
  {
    id: 11,
    name: "Justice",
    nameLatin: "La Justice",
    meaning: {
      upright: "Keadilan, kebenaran, sebab-akibat, hukum",
      reversed: "Ketidakadilan, ketidakjujuran, kurang akuntabilitas"
    },
    description: "Dewi keadilan yang memegang timbangan dan pedang kebenaran.",
    imageUrl: "https://images.unsplash.com/photo-1589578527966-fdac0f44566c?w=400&h=600&fit=crop"
  },
  {
    id: 12,
    name: "The Hanged Man",
    nameLatin: "Le Pendu",
    meaning: {
      upright: "Pengorbanan, pelepasan, perspektif baru",
      reversed: "Penundaan, penolakan, stagnasi"
    },
    description: "Tergantung terbalik namun bersinar dengan pencerahan.",
    imageUrl: "https://images.unsplash.com/photo-1508739773434-c26b3d09e071?w=400&h=600&fit=crop"
  },
  {
    id: 13,
    name: "Death",
    nameLatin: "La Mort",
    meaning: {
      upright: "Akhir, transformasi, transisi, perubahan",
      reversed: "Penolakan perubahan, stagnasi, ketakutan"
    },
    description: "Bukan kematian literal, melainkan transformasi dan kelahiran kembali.",
    imageUrl: "https://images.unsplash.com/photo-1509248961895-b79e1b8bdf29?w=400&h=600&fit=crop"
  },
  {
    id: 14,
    name: "Temperance",
    nameLatin: "Tempérance",
    meaning: {
      upright: "Keseimbangan, moderasi, kesabaran, tujuan",
      reversed: "Ketidakseimbangan, kelebihan, kurang harmoni"
    },
    description: "Malaikat yang mencampur air antara dua cawan dengan sempurna.",
    imageUrl: "https://images.unsplash.com/photo-1504893524553-b855bce32c67?w=400&h=600&fit=crop"
  },
  {
    id: 15,
    name: "The Devil",
    nameLatin: "Le Diable",
    meaning: {
      upright: "Belenggu, kecanduan, seksualitas, materialisme",
      reversed: "Pembebasan, pelepasan, eksplorasi sisi gelap"
    },
    description: "Pengikat jiwa yang mengingatkan akan belenggu yang kita ciptakan sendiri.",
    imageUrl: "https://images.unsplash.com/photo-1509281373149-e957c6296406?w=400&h=600&fit=crop"
  },
  {
    id: 16,
    name: "The Tower",
    nameLatin: "La Maison Dieu",
    meaning: {
      upright: "Kehancuran tiba-tiba, kekacauan, revelasi",
      reversed: "Penghindaran bencana, ketakutan akan perubahan"
    },
    description: "Menara yang tersambar petir, menghancurkan ilusi palsu.",
    imageUrl: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=400&h=600&fit=crop"
  },
  {
    id: 17,
    name: "The Star",
    nameLatin: "L'Étoile",
    meaning: {
      upright: "Harapan, iman, pembaruan, ketenangan",
      reversed: "Keputusasaan, kehilangan iman, tidak terkoneksi"
    },
    description: "Dewi yang menuangkan air kehidupan di bawah bintang-bintang.",
    imageUrl: "https://images.unsplash.com/photo-1419242902214-272b3f66ee7a?w=400&h=600&fit=crop"
  },
  {
    id: 18,
    name: "The Moon",
    nameLatin: "La Lune",
    meaning: {
      upright: "Ilusi, ketakutan, kecemasan, alam bawah sadar",
      reversed: "Pelepasan ketakutan, kejelasan, pemahaman"
    },
    description: "Bulan yang menyembunyikan kebenaran di balik bayang-bayang.",
    imageUrl: "https://images.unsplash.com/photo-1532693322450-2cb5c511067d?w=400&h=600&fit=crop"
  },
  {
    id: 19,
    name: "The Sun",
    nameLatin: "Le Soleil",
    meaning: {
      upright: "Sukacita, kesuksesan, vitalitas, kebenaran",
      reversed: "Negativitas tertahan, depresi ringan"
    },
    description: "Matahari yang menyinari segala kebenaran dan membawa kebahagiaan.",
    imageUrl: "https://images.unsplash.com/photo-1495616811223-4d98c6e9c869?w=400&h=600&fit=crop"
  },
  {
    id: 20,
    name: "Judgement",
    nameLatin: "Le Jugement",
    meaning: {
      upright: "Kebangkitan, refleksi, evaluasi, panggilan",
      reversed: "Keraguan diri, penolakan panggilan"
    },
    description: "Malaikat yang meniup terompet, memanggil jiwa untuk bangkit.",
    imageUrl: "https://images.unsplash.com/photo-1475137979732-b349acb6b7e3?w=400&h=600&fit=crop"
  },
  {
    id: 21,
    name: "The World",
    nameLatin: "Le Monde",
    meaning: {
      upright: "Penyelesaian, integrasi, pencapaian, perjalanan",
      reversed: "Kurang penutupan, tidak lengkap"
    },
    description: "Penari di dalam lingkaran keabadian, simbol kesempurnaan siklus.",
    imageUrl: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=400&h=600&fit=crop"
  }
]

export interface DrawnCard {
  card: TarotCard
  isReversed: boolean
  isRevealed: boolean
}

export function shuffleAndDraw(count: number): DrawnCard[] {
  const shuffled = [...majorArcana].sort(() => Math.random() - 0.5)
  const drawn = shuffled.slice(0, count)
  
  return drawn.map(card => ({
    card,
    isReversed: Math.random() > 0.5,
    isRevealed: false
  }))
}
