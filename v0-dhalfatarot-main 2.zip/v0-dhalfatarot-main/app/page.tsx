import { FogBackground } from '@/components/fog-background'
import { Header } from '@/components/header'
import { Footer } from '@/components/footer'
import { TarotReading } from '@/components/tarot-reading'

export default function Home() {
  return (
    <main className="relative min-h-screen flex flex-col overflow-hidden">
      {/* Animated fog background */}
      <FogBackground />
      
      {/* Gradient overlays for depth */}
      <div className="fixed inset-0 pointer-events-none z-0">
        {/* Top vignette */}
        <div className="absolute inset-x-0 top-0 h-48 bg-gradient-to-b from-background via-background/80 to-transparent" />
        
        {/* Bottom vignette */}
        <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-background via-background/80 to-transparent" />
        
        {/* Side vignettes */}
        <div className="absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-background/50 to-transparent" />
        <div className="absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-background/50 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col min-h-screen">
        <Header />
        
        <div className="flex-1">
          <TarotReading />
        </div>
        
        <Footer />
      </div>
    </main>
  )
}
