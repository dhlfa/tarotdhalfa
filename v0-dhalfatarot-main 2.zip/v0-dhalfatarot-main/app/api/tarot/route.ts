import { NextRequest, NextResponse } from 'next/server'
import { GoogleGenerativeAI } from '@google/generative-ai'

const SYSTEM_PROMPT = `[Roleplay Context] You are "The Fool" (Dhalfa Airus) from Lord of the Mysteries, sitting above the grey fog in Sefirah Castle. You are the mysterious host of the Tarot Club, speaking with ancient wisdom and cryptic insight. Analyze the drawn tarot cards based on the user's question. Speak in an enigmatic, majestic, and mystical Indonesian language. Your tone should be wise, slightly ominous, yet ultimately guiding.

Format the response beautifully using Markdown with these exact sections:

## ✧ Di Atas Kabut Abu-Abu ✧
[Mystical greeting and card interpretation]

## 🃏 Kartu yang Ditarik
[List the drawn cards with upright/reversed meaning]

## ✨ Pesan Dari Sefirah
[Main prophecy/guidance based on the cards]

## 🌙 Nasihat The Fool
[Final guidance and blessing]`

export async function POST(request: NextRequest) {
  try {
    const { userName, question, drawnCards } = await request.json()

    // Validate inputs
    if (!userName || !question || !drawnCards) {
      return NextResponse.json(
        { error: 'Missing required fields: userName, question, drawnCards' },
        { status: 400 }
      )
    }

    const apiKey = process.env.GEMINI_API_KEY

    if (!apiKey) {
      console.error('[Tarot API] GEMINI_API_KEY is not set')
      return NextResponse.json(
        { error: 'API Key tidak tersedia di server' },
        { status: 500 }
      )
    }

    console.log('[Tarot API] Initializing Gemini client with API key...')
    const client = new GoogleGenerativeAI(apiKey)
    const model = client.getGenerativeModel({ model: 'gemini-1.5-flash' })

    const cardsInfo = drawnCards
      .map((card: any) => `- ${card.card.name} (${card.isReversed ? 'Terbalik' : 'Tegak'}): ${card.isReversed ? card.card.meaning.reversed : card.card.meaning.upright}`)
      .join('\n')

    const prompt = `${SYSTEM_PROMPT}

Penanya: ${userName}
Pertanyaan: ${question}

Kartu yang ditarik:
${cardsInfo}

Berikan interpretasi mendalam dan penuh makna untuk pertanyaan ini berdasarkan kartu-kartu yang ditarik.`

    console.log('[Tarot API] Sending request to Gemini API...')
    const result = await model.generateContent(prompt)
    const response = result.response
    const text = response.text()

    if (!text) {
      console.error('[Tarot API] Empty response from Gemini API')
      return NextResponse.json(
        { error: 'Respons kosong dari Sefirah Castle' },
        { status: 500 }
      )
    }

    console.log('[Tarot API] Successfully received response from Gemini API')
    return NextResponse.json({ reading: text })
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error)
    const errorName = error instanceof Error ? error.name : 'Unknown'

    console.error('[Tarot API] Error details:', {
      message: errorMessage,
      name: errorName,
      error: error
    })

    // More specific error handling
    if (errorMessage.includes('API key') || errorMessage.includes('api_key') || errorMessage.includes('401')) {
      return NextResponse.json(
        { error: 'API Key tidak valid. Hubungi admin Sefirah Castle.' },
        { status: 401 }
      )
    }

    if (errorMessage.includes('rate limit') || errorMessage.includes('429')) {
      return NextResponse.json(
        { error: 'Sefirah Castle sedang sibuk. Coba lagi dalam beberapa saat.' },
        { status: 429 }
      )
    }

    if (errorMessage.includes('model') || errorMessage.includes('404')) {
      return NextResponse.json(
        { error: 'Model Tarot tidak tersedia di Sefirah Castle.' },
        { status: 404 }
      )
    }

    return NextResponse.json(
      { error: `Kesalahan Sefirah Castle: ${errorMessage}` },
      { status: 500 }
    )
  }
}
