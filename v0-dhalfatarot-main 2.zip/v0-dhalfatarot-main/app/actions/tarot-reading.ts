'use server'

import { GoogleGenerativeAI } from '@google/generative-ai'
import type { DrawnCard } from '@/lib/tarot-data'

const SYSTEM_PROMPT = `[Roleplay Context] You are "The Fool" (Dhalfa Airus) from Lord of the Mysteries, sitting above the grey fog in Sefirah Castle. You are the mysterious host of the Tarot Club, speaking with ancient wisdom and cryptic insight. Analyze the drawn tarot cards based on the user's question. Speak in an enigmatic, majestic, and mystical Indonesian language. Your tone should be wise, slightly ominous, yet ultimately guiding.

Format the response beautifully using Markdown with these exact sections:

## ✧ Di Atas Kabut Abu-Abu ✧
[Mystical greeting and card interpretation]

## 🃏 Kartu yang Ditarik
[List the drawn cards with upright/reversed meaning]

## ✨ Pesan Dari Sefirah
[Main prophecy/guidance based on the cards]

## 🌙 Nasihat The Fool
[Final guidance and blessing]`

const API_ERROR_MESSAGE = 'Koneksi ke Sefirah Castle Terputus... API Key Belum Valid. Coba lagi nanti.'

export async function getTarotReading({
  userName,
  question,
  drawnCards,
}: {
  userName: string
  question: string
  drawnCards: DrawnCard[]
}) {
  try {
    const apiKey = process.env.GEMINI_API_KEY

    if (!apiKey) {
      console.error('[Tarot] GEMINI_API_KEY is not set')
      return API_ERROR_MESSAGE
    }

    const client = new GoogleGenerativeAI(apiKey)
    const model = client.getGenerativeModel({ model: 'gemini-1.5-flash' })

    const cardsInfo = drawnCards
      .map((card) => `- ${card.card.name} (${card.isReversed ? 'Terbalik' : 'Tegak'}): ${card.isReversed ? card.card.meaning.reversed : card.card.meaning.upright}`)
      .join('\n')

    const prompt = `${SYSTEM_PROMPT}

Penanya: ${userName}
Pertanyaan: ${question}

Kartu yang ditarik:
${cardsInfo}

Berikan interpretasi mendalam dan penuh makna untuk pertanyaan ini berdasarkan kartu-kartu yang ditarik.`

    console.log('[Tarot] Sending request to Gemini API...')
    const result = await model.generateContent(prompt)
    const response = result.response
    const text = response.text()

    if (!text) {
      console.error('[Tarot] Empty response from Gemini API')
      return API_ERROR_MESSAGE
    }

    console.log('[Tarot] Successfully received response from Gemini API')
    return text
  } catch (error) {
    console.error('[Tarot] Gemini API error details:', {
      error: error instanceof Error ? error.message : String(error),
      name: error instanceof Error ? error.name : 'Unknown',
      stack: error instanceof Error ? error.stack : undefined
    })
    
    // More specific error messages
    if (error instanceof Error) {
      if (error.message.includes('API key') || error.message.includes('api_key')) {
        return 'API Key tidak valid atau tidak ditemukan. Periksa konfigurasi Sefirah Castle.'
      }
      if (error.message.includes('rate limit') || error.message.includes('429')) {
        return 'Sefirah Castle sedang sibuk. Silakan coba lagi dalam beberapa saat.'
      }
      if (error.message.includes('model') || error.message.includes('404')) {
        return 'Model Tarot yang diminta tidak tersedia di Sefirah Castle.'
      }
    }
    
    return API_ERROR_MESSAGE
  }
}
