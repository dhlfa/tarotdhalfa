import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Cinzel, Crimson_Text } from 'next/font/google'
import './globals.css'

const cinzel = Cinzel({ 
  variable: '--font-cinzel', 
  subsets: ['latin'],
  weight: ['400', '500', '600', '700']
})

const crimsonText = Crimson_Text({
  variable: '--font-crimson-text',
  subsets: ['latin'],
  weight: ['400', '600', '700']
})

export const metadata: Metadata = {
  title: 'The Tarot Club Above the Grey Fog | Lord of the Mysteries',
  description: 'Seek divine guidance from The Fool above the grey fog. A mystical tarot reading experience inspired by Lord of the Mysteries. Created by Dhalfa Airus (The Fool).',
  generator: 'v0.app',
  keywords: ['tarot', 'lord of mysteries', 'grey fog', 'tarot club', 'fortune telling', 'mystical'],
  authors: [{ name: 'Dhalfa Airus (The Fool)' }],
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  themeColor: '#0d0d14',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="id" className={`${cinzel.variable} ${crimsonText.variable} bg-background`}>
      <body className="font-sans antialiased min-h-screen">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
